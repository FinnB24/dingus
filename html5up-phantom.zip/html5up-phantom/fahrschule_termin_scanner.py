import time
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import winsound
from plyer import notification  # For desktop notifications

# Configuration
URL = "https://termine-reservieren.de/termine/verkehrsueberwachung.mainz"
MAX_RETRIES = 3
DELAY_BETWEEN_CHECKS = 3600  # Seconds between checks (1 hour)

def send_desktop_notification(message):
    """Send a desktop notification"""
    try:
        notification.notify(
            title='YES',
            message=message,
            app_name='Termin Checker',
            timeout=30
        )
    except Exception as e:
        print(f"Could not send notification: {e}")

def notify_user(message):
    print("\a")  # System beep
    print(f"!!! NOTIFICATION: {message} !!!")
    send_desktop_notification(message)




def notify_disappointment(message):
    print("\a")  # System beep
    print(f"!!! NOTIFICATION: {message} !!!")
    send_disappointment(message)

def send_disappointment(message):
    """Send a desktop notification"""
    try:
        notification.notify(
            title='NO ',
            message=message,
            app_name='Termin Checker',
            timeout=10
        )
    except Exception as e:
        print(f"Could not send notification: {e}")



def setup_driver():
    """Initialize browser driver"""
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")  # For headless mode
    driver = webdriver.Chrome(options=options)
    driver.implicitly_wait(10)
    return driver

def navigate_to_appointment_selection(driver):
    """Navigate through the form to appointment selection"""
    try:
        print("Navigating to website...")
        driver.get(URL)
        
        # Accept cookies if present
        try:
            cookie_accept = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "cookie_msg_btn_yes"))
            )
            cookie_accept.click()
            print("Accepted cookie banner")
        except:
            pass
        
        print("Selecting driving license office...")
        fs_button = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'Fahrerlaubnisbehörde')]"))
        )
        fs_button.click()
        
        print("Opening concerns dropdown...")
        accordion = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.XPATH, "//h3[contains(., 'Ersterteilung / bF 17 / Erweiterung / Verlängerung')]"))
        )
        accordion.click()
        
        print("Finding the correct row for first issuance...")
        ersterteilung_label = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.XPATH, "//label[contains(., 'Ersterteilung einer Fahrerlaubnis (kein begleitendes Fahren ab 17!)')]"))
        )
        
        container = ersterteilung_label.find_element(By.XPATH, "./ancestor::div[contains(@class, 'containerConcerns')]")
        
        print("Clicking plus button in this row...")
        plus_button = container.find_element(By.XPATH, ".//button[contains(@class, 'btn-number') and @data-type='plus']")
        plus_button.click()
        print("Plus button clicked")
        
        print("Waiting for OK popup...")
        ok_button = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'OK')]"))
        )
        ok_button.click()
        print("OK popup confirmed")
        
        print("Finding 'Weiter' button...")
        weiter_button = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "html body.TEVISWEB main.container.wrapper div#inhalt.content.content--mdt div.button_container.row form#cnc-select-form input#WeiterButton.sel_button.btn.btn-primary.pull-right.fifty"))
        )
        
        print("Scrolling to 'Weiter' button...")
        driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", weiter_button)
        time.sleep(0.5)
        
        print("Clicking 'Weiter' button...")
        weiter_button = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "html body.TEVISWEB main.container.wrapper div#inhalt.content.content--mdt div.button_container.row form#cnc-select-form input#WeiterButton.sel_button.btn.btn-primary.pull-right.fifty"))
        )
        weiter_button.click()
        print("'Weiter' button clicked")
        
        print("Waiting for second OK popup...")
        ok_button = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'OK')]"))
        )
        ok_button.click()
        print("Second OK popup confirmed")
        
        return True
    
    except Exception as e:
        print(f"Error navigating through form: {str(e)}")
        driver.save_screenshot("error_screenshot.png")
        return False


def check_for_earlier_appointment(driver):
    """Check if an earlier appointment is available"""
    try:
        print("Checking for available appointments...")
        # Wait for the location selection page to load
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "html body.TEVISWEB main.container.wrapper div#inhalt.content.content--location"))
        )
        
        # Find the date element - using the exact location from the HTML you provided
        date_element = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.XPATH, "//dt[contains(., 'Nächster Termin')]/following-sibling::dd"))
        )
        
        date_text = date_element.text
        print(f"Available appointment text: '{date_text}'")
        
        # Extract the date part (format: "ab 07.08.2025, 13:00 Uhr")
        date_str = date_text.replace("ab ", "").split(",")[0].strip()
        time_str = date_text.split(",")[1].strip().split()[0]
        
        print(f"Extracted date: '{date_str}', time: '{time_str}'")
        
        # Parse the date (format: DD.MM.YYYY)
        day, month, year = date_str.split(".")
        parsed_date = datetime.strptime(f"{day}.{month}.{year} {time_str}", "%d.%m.%Y %H:%M")
        
       
############################################ YOUR TERMIN HERE ############################################
        last_booked = datetime.strptime("2025-07-31 14:00", "%Y-%m-%d %H:%M")
##########################################################################################################

        print(f"Comparing dates - Available: {parsed_date} vs Your appointment: {last_booked}")
        
        if parsed_date < last_booked:
            message = f"NEW: {date_text}                                      OLD: {last_booked}"
            notify_user(message)
            return True
        else:
            message = f"NO EARLIER APPOINTMENT AVAILABLE!!                NEWEST: {parsed_date}                      YOURS: {last_booked}"
            notify_disappointment(message)
            return True
    
    except Exception as e:
        print(f"Error checking appointment: {str(e)}")
        return False
    

def main():
    driver = setup_driver()
    retries = 0
    
    try:
        while retries < MAX_RETRIES:
            print(f"\n--- Attempt {retries + 1} of {MAX_RETRIES} ---")
            
            if navigate_to_appointment_selection(driver):
                if check_for_earlier_appointment(driver):
                    break  # Success - earlier appointment found
                else:
                    print("No earlier appointment found. Ending program.")
                    break
            
            retries += 1
            if retries < MAX_RETRIES:
                print(f"Waiting {DELAY_BETWEEN_CHECKS} seconds before next attempt...")
                time.sleep(DELAY_BETWEEN_CHECKS)
                driver.refresh()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    main()