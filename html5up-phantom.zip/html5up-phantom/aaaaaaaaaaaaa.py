import os
from flask import Flask, render_template_string, request, redirect, url_for, session, flash
from flask_session import Session
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

SPOTIFY_CLIENT_ID = os.getenv('1a3bd3799db74ad382d1724536885c8c') or '1a3bd3799db74ad382d1724536885c8c'
SPOTIFY_CLIENT_SECRET = os.getenv('330edb62c8424c22b41e05a71a2eaa9e') or '330edb62c8424c22b41e05a71a2eaa9e'
SECRET_KEY = os.getenv('FLASK_SECRET_KEY') or 'super_secret_key'
app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = './flask_session_data'
Session(app)

sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET
))

INDEX_HTML = '''
<!doctype html>
<html>
  <head>
    <title>Music Tierlist</title>
    <style>
      html, body {
        background: #181c22;
        color: #f5f7fa;
        font-family: 'Segoe UI', Arial, sans-serif;
        min-height: 100vh;
      }
      body {
        max-width: 1080px;
        margin: 0 auto;
        padding: 0;
      }
      input[type="text"], button {
        background: #23272f;
        color: #f5f7fa;
        border: none;
        border-radius: 6px;
        font-size: 1.5em;
        padding: 18px;
        margin-bottom: 16px;
        width: 100%;
      }
      input[type="radio"] {
        accent-color: #1db954;
        transform: scale(1.4);
      }
      button {
        background: #1db954;
        color: #fff;
        font-weight: bold;
        cursor: pointer;
        margin-top: 24px;
        width: auto;
        font-size: 1.3em;
        padding: 14px 48px;
      }
      button:hover {
        background: #17a34a;
      }
      .form-box {
        background: #21242b;
        border-radius: 18px;
        padding: 60px 60px 40px 60px;
        box-shadow: 0 2px 32px #0005;
        margin: 80px auto 0 auto;
        max-width: 700px;
      }
      .error {
        background: #ff3333;
        color: white;
        padding: 16px 22px;
        margin-top: 30px;
        border-radius: 8px;
        font-size: 1.2em;
      }
      h1 {
        color: #1db954;
        margin-bottom: 48px;
        text-align: center;
        font-size: 2.9em;
        letter-spacing: 1px;
      }
      label {
        color: #dbe6f7;
        margin-top: 20px;
        display: block;
        font-size: 1.35em;
      }
      .radio-row {
        margin: 18px 0 35px 0;
        font-size: 1.2em;
      }
    </style>
  </head>
  <body>
    <div class="form-box">
      <h1>Spotify Playlist Tierlist</h1>
      <form method="POST">
        <label>
          Spotify Playlist URL:
          <input type="text" name="playlist_url" required>
        </label>
        <div class="radio-row">
          <label><input type="radio" name="mode" value="album" checked> Tierlist by Album</label>
          <label style="margin-left: 60px;"><input type="radio" name="mode" value="full"> Tierlist for Full Playlist</label>
        </div>
        <button type="submit">Start</button>
      </form>
      {% if error %}
      <div class="error">{{ error }}</div>
      {% endif %}
      {% with messages = get_flashed_messages() %}
        {% if messages %}
          <div class="error">{{ messages[0] }}</div>
        {% endif %}
      {% endwith %}
    </div>
  </body>
</html>
'''

PAIR_HTML = '''
<!doctype html>
<html>
  <head>
    <title>Tierlist: {{ header }}</title>
    <meta name="viewport" content="width=1080">
    <style>
      html, body {
        background: #181c22;
        color: #f5f7fa;
        font-family: 'Segoe UI', Arial, sans-serif;
        min-height: 100vh;
        margin: 0;
        padding: 0;
      }
      .main-flex {
        display: flex;
        gap: 40px;
        margin: 0 auto;
        max-width: 1600px;
        min-height: 100vh;
        align-items: flex-start;
      }
      .pair-box {
        background: #23272f;
        border-radius: 18px;
        padding: 56px 56px 36px 56px;
        box-shadow: 0 2px 32px #0004;
        margin: 80px 0 0 0;
        flex: 2 1 0;
        min-width: 0;
        position: relative;
        font-size: 1.6em;
      }
      .track-name {
        font-size: 1.35em;
        font-weight: bold;
        color: #1db954;
      }
      .info {
        color: #a2aab8;
        font-size: 1.05em;
        margin-bottom: 16px;
      }
      .progress {
        margin-bottom: 32px;
        color: #b7c8d3;
        font-size: 1.25em;
      }
      .album-header {
        font-size: 1.25em;
        margin-bottom: 24px;
      }
      .choose-row {
        display: flex;
        justify-content: space-between;
        gap: 52px;
      }
      .choose-col {
        flex: 1 1 50%;
        display: flex;
        flex-direction: column;
        align-items: center;
        background: #21242b;
        border-radius: 12px;
        padding: 36px 12px 30px 12px;
        min-width: 320px;
      }
      .vs {
        align-self: center;
        font-size: 3em;
        font-weight: bold;
        color: #b2f5ea;
        margin: 0 18px;
      }
      button {
        background: #1db954;
        color: #fff;
        font-weight: bold;
        font-size: 1.25em;
        border: none;
        border-radius: 8px;
        margin-top: 18px;
        padding: 14px 48px;
        cursor: pointer;
        transition: background 0.2s;
      }
      button:hover {
        background: #17a34a;
      }
      .spotify-embed {
        margin: 18px 0;
        width: 550px;
        height: 180px;
        border-radius: 14px;
        box-shadow: 0 2px 12px #0005;
        border: none;
        background: #191414;
        max-width: 95vw;
      }
      .cancel-row {
        margin-top: 40px;
        text-align: center;
      }
      .cancel-row button {
        background: #23272f;
        color: #f5f7fa;
        font-weight: normal;
        font-size: 1.12em;
        border: 1px solid #38444d;
        padding: 12px 38px;
        margin-top: 0;
        border-radius: 8px;
      }
      .cancel-row button:hover {
        background: #38444d;
      }
      .sidebar {
        background: #21242b;
        border-radius: 16px;
        padding: 38px 24px 24px 24px;
        min-width: 320px;
        max-width: 420px;
        margin-top: 80px;
        flex: 1 1 0;
        position: sticky;
        top: 40px;
        height: fit-content;
        box-shadow: 0 2px 24px #0003;
      }
      .sidebar h2 {
        color: #1db954;
        font-size: 1.5em;
        margin-bottom: 26px;
        letter-spacing: 1px;
        text-align: center;
      }
      .ranked-song {
        display: flex;
        align-items: center;
        gap: 22px;
        margin-bottom: 18px;
        padding: 10px 0 10px 0;
        border-bottom: 1px solid #333a45;
      }
      .rank-num {
        font-size: 1.7em;
        font-weight: bold;
        color: #dbe6f7;
        width: 38px;
        text-align: right;
      }
      .song-details {
        flex: 1 1 auto;
        min-width: 0;
        overflow: hidden;
      }
      .sidebar-track-name {
        font-size: 1.15em;
        font-weight: bold;
        color: #1db954;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 210px;
        display: inline-block;
      }
      .sidebar-info {
        color: #a2aab8;
        font-size: 0.92em;
        display: block;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 210px;
      }
      /* NO EMBEDS in sidebar ranking! */
      .sidebar-spotify-embed {
        display: none !important;
      }
      @media (max-width: 1200px) {
        .main-flex { flex-direction: column; gap: 0; }
        .sidebar { position: static; max-width: none; width: 100%; margin: 32px 0 0 0; }
      }
      @media (max-width: 900px) {
        .pair-box { padding: 32px 4vw; }
        .sidebar { padding: 24px 2vw; }
        .choose-col { padding: 16px 4px 10px 4px; min-width: 0; }
        .spotify-embed { width: 100%; min-width: 0; }
      }
    </style>
  </head>
  <body>
    <div class="main-flex">
      <div class="pair-box">
        <div class="progress">Comparison {{ progress }}/{{ total }}</div>
        <form method="POST">
          <div class="choose-row">
            <div class="choose-col">
              <span class="track-name">{{ track1['name'] }}</span>
              {% if track1['artists'] %}
                <span class="info">by {{ ', '.join(track1['artists']) }}</span>
              {% endif %}
              {% if track1['external_url'] %}
                <iframe class="spotify-embed" src="https://open.spotify.com/embed/track/{{ track1['id'] }}" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
              {% elif track1['preview_url'] %}
                <audio controls src="{{ track1['preview_url'] }}" style="width: 100%;"></audio>
                <div class="info">30s preview</div>
              {% else %}
                <div class="info">No preview available</div>
              {% endif %}
              <button name="winner" value="0" type="submit">Choose</button>
            </div>
            <div class="vs">   </div>
            <div class="choose-col">
              <span class="track-name">{{ track2['name'] }}</span>
              {% if track2['artists'] %}
                <span class="info">by {{ ', '.join(track2['artists']) }}</span>
              {% endif %}
              {% if track2['external_url'] %}
                <iframe class="spotify-embed" src="https://open.spotify.com/embed/track/{{ track2['id'] }}" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
              {% elif track2['preview_url'] %}
                <audio controls src="{{ track2['preview_url'] }}" style="width: 100%;"></audio>
                <div class="info">30s preview</div>
              {% else %}
                <div class="info">No preview available</div>
              {% endif %}
              <button name="winner" value="1" type="submit">Choose</button>
            </div>
          </div>
        </form>
        <div class="cancel-row">
          <form method="POST" action="{{ url_for('cancel') }}">
            <button>Cancel and Return to Home</button>
          </form>
        </div>
      </div>
      <div class="sidebar">
        <h2>Current Ranking</h2>
        {% if ranking %}
          {% for song in ranking %}
            <div class="ranked-song">
              <div class="rank-num">#{{ loop.index }}</div>
              <div class="song-details">
                <span class="sidebar-track-name">{{ song['name'] }}</span>
                {% if song['artists'] %}
                  <span class="sidebar-info">by {{ ', '.join(song['artists']) }}</span>
                {% endif %}
              </div>
            </div>
          {% endfor %}
        {% else %}
          <div class="info">No results yet.</div>
        {% endif %}
      </div>
    </div>
  </body>
</html>
'''

RESULTS_HTML = '''
<!doctype html>
<html>
  <head>
    <title>Your Tierlist Results</title>
    <style>
      html, body {
        background: #181c22;
        color: #f5f7fa;
        font-family: 'Segoe UI', Arial, sans-serif;
        min-height: 100vh;
      }
      body {
        max-width: 1080px;
        margin: 0 auto;
        padding: 0;
      }
      .result-list {
        margin-top: 40px;
        background: #23272f;
        border-radius: 18px;
        padding: 40px 34px;
      }
      .album-header {
        margin-top: 40px;
        font-size: 1.35em;
        color: #1db954;
      }
      .ranked-song {
        margin-bottom: 20px;
        background: #21242b;
        padding: 18px 20px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 30px;
        font-size: 1.25em;
      }
      .rank-num {
        font-size: 1.5em;
        font-weight: bold;
        color: #dbe6f7;
        width: 32px;
        text-align: right;
      }
      .track-name {
        font-weight: bold;
        font-size: 1.18em;
        color: #1db954;
      }
      .info {
        color: #a2aab8;
        font-size: 0.97em;
      }
      /* Album results only: display bigger embed */
      .spotify-embed {
        margin-left: 8px;
        width: 420px;
        height: 140px;
        border-radius: 14px;
        border: none;
        max-width: 90vw;
      }
      .back-link {
        color: #1db954;
        font-size: 1.25em;
        text-decoration: underline;
        display: inline-block;
        margin: 48px 0 30px 0;
      }
      h1 {
        color: #1db954;
        font-size: 2.5em;
        letter-spacing: 1px;
        text-align: center;
        margin-top: 40px;
      }
    </style>
  </head>
  <body>
    <h1>Your Tierlist Results</h1>
    {% if album_results %}
      {% for album, ranked in album_results.items() %}
        <div class="album-header">{{ album }}</div>
        <ol class="result-list">
          {% for song in ranked %}
            <li class="ranked-song">
              <div class="rank-num">#{{ loop.index }}</div>
              <span class="track-name">{{ song['name'] }}</span>
              {% if song['artists'] %}
                <span class="info">by {{ ', '.join(song['artists']) }}</span>
              {% endif %}
              {% if song['external_url'] %}
                <iframe class="spotify-embed" src="https://open.spotify.com/embed/track/{{ song['id'] }}" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
              {% endif %}
            </li>
          {% endfor %}
        </ol>
      {% endfor %}
    {% else %}
      <ol class="result-list">
        {% for song in playlist_result %}
          <li class="ranked-song">
            <div class="rank-num">#{{ loop.index }}</div>
            <span class="track-name">{{ song['name'] }}</span>
            {% if song['artists'] %}<span class="info">by {{ ', '.join(song['artists']) }}</span>{% endif %}
            <!-- NO EMBED for playlist result -->
          </li>
        {% endfor %}
      </ol>
    {% endif %}
    <a href="{{ url_for('index') }}" class="back-link">Start Another Tierlist</a>
  </body>
</html>
'''

def get_playlist_tracks(playlist_url):
    try:
        if "playlist/" in playlist_url:
            playlist_id = playlist_url.split("playlist/")[1].split("?")[0]
        else:
            playlist_id = playlist_url.split("/")[-1].split("?")[0]
        results = sp.playlist_tracks(playlist_id)
        tracks = []
        while True:
            for item in results['items']:
                track = item['track']
                if not track or not track.get('id'):
                    continue
                tracks.append({
                    'id': track['id'],
                    'name': track['name'],
                    'album': track['album']['name'],
                    'album_id': track['album']['id'],
                    'artists': [artist['name'] for artist in track['artists']],
                    'preview_url': track['preview_url'],
                    'external_url': track['external_urls']['spotify']
                })
            if results['next']:
                results = sp.next(results)
            else:
                break
        return tracks
    except Exception as e:
        print(f"Spotify error: {e}")
        return None

def group_tracks_by_album(tracks):
    albums = {}
    for track in tracks:
        album = track['album']
        if album not in albums:
            albums[album] = []
        albums[album].append(track)
    return albums

def generate_pairs(n):
    return [(i, j) for i in range(n) for j in range(i+1, n)]

def update_scores(scores, idx_win, idx_lose):
    scores[idx_win] += 1

def rank_tracks(tracks, pair_results):
    n = len(tracks)
    scores = [0] * n
    for win, lose in pair_results:
        update_scores(scores, win, lose)
    sorted_indices = sorted(range(n), key=lambda i: -scores[i])
    return [tracks[i] for i in sorted_indices]

@app.route('/', methods=['GET', 'POST'])
def index():
    error = None
    if request.method == 'POST':
        playlist_url = request.form['playlist_url'].strip()
        mode = request.form['mode']
        tracks = get_playlist_tracks(playlist_url)
        if not tracks:
            error = "Failed to fetch playlist. Make sure it is public and the link is correct."
            return render_template_string(INDEX_HTML, error=error)
        if len(tracks) < 2:
            error = "Playlist must have at least 2 tracks."
            return render_template_string(INDEX_HTML, error=error)
        session.clear()
        session['mode'] = mode
        session['tracks'] = tracks
        if mode == 'album':
            albums = group_tracks_by_album(tracks)
            session['albums'] = albums
            session['album_names'] = list(albums.keys())
            session['album_idx'] = 0
            session['album_tierlists'] = {}
            return redirect(url_for('tierlist_album'))
        else:
            pairs = generate_pairs(len(tracks))
            if not pairs:
                error = "Playlist must have at least 2 tracks."
                return render_template_string(INDEX_HTML, error=error)
            session['pairs'] = pairs
            session['pair_idx'] = 0
            session['pair_results'] = []
            return redirect(url_for('tierlist_playlist'))
    return render_template_string(INDEX_HTML, error=error)

@app.route('/tierlist/album', methods=['GET', 'POST'])
def tierlist_album():
    albums = session.get('albums')
    album_names = session.get('album_names')
    album_idx = session.get('album_idx', 0)
    album_tierlists = session.get('album_tierlists', {})
    if not albums or not album_names or album_idx >= len(album_names):
        session['album_tierlists'] = album_tierlists
        return redirect(url_for('results'))

    album = album_names[album_idx]
    tracks = albums[album]
    if len(tracks) < 2:
        album_tierlists[album] = tracks
        session['album_idx'] = album_idx + 1
        session['album_tierlists'] = album_tierlists
        return redirect(url_for('tierlist_album'))

    if 'album_pair_idx' not in session:
        session['album_pairs'] = generate_pairs(len(tracks))
        session['album_pair_idx'] = 0
        session['album_pair_results'] = []

    pairs = session.get('album_pairs')
    pair_idx = session.get('album_pair_idx', 0)
    pair_results = session.get('album_pair_results', [])

    if not pairs:
        session['album_idx'] = album_idx + 1
        session['album_tierlists'] = album_tierlists
        return redirect(url_for('tierlist_album'))

    if request.method == 'POST':
        winner = int(request.form['winner'])
        i, j = pairs[pair_idx]
        pair_results.append((i if winner == 0 else j, j if winner == 0 else i))
        pair_idx += 1
        session['album_pair_idx'] = pair_idx
        session['album_pair_results'] = pair_results

    current_ranking = rank_tracks(tracks, pair_results) if pair_results else tracks

    if pair_idx >= len(pairs):
        ranked = rank_tracks(tracks, pair_results)
        album_tierlists[album] = ranked
        session['album_idx'] = album_idx + 1
        session['album_tierlists'] = album_tierlists
        session.pop('album_pairs', None)
        session.pop('album_pair_idx', None)
        session.pop('album_pair_results', None)
        return redirect(url_for('tierlist_album'))

    i, j = pairs[pair_idx]
    progress = pair_idx + 1
    total = len(pairs)
    return render_template_string(
        PAIR_HTML,
        header=album,
        track1=tracks[i],
        track2=tracks[j],
        progress=progress,
        total=total,
        ranking=current_ranking,
        show_embeds=True
    )

@app.route('/tierlist/playlist', methods=['GET', 'POST'])
def tierlist_playlist():
    tracks = session.get('tracks')
    pairs = session.get('pairs')
    pair_idx = session.get('pair_idx', 0)
    pair_results = session.get('pair_results', [])

    if not tracks or not pairs or len(tracks) < 2 or len(pairs) < 1:
        session.clear()
        flash("Session error or playlist too short. Please start again with a public playlist containing at least 2 tracks.")
        return redirect(url_for('index'))

    if request.method == 'POST':
        winner = int(request.form['winner'])
        i, j = pairs[pair_idx]
        pair_results.append((i if winner == 0 else j, j if winner == 0 else i))
        pair_idx += 1
        session['pair_idx'] = pair_idx
        session['pair_results'] = pair_results

    current_ranking = rank_tracks(tracks, pair_results) if pair_results else tracks

    if pair_idx >= len(pairs):
        ranked = rank_tracks(tracks, pair_results)
        session['playlist_result'] = ranked
        return redirect(url_for('results'))

    i, j = pairs[pair_idx]
    progress = pair_idx + 1
    total = len(pairs)
    return render_template_string(
        PAIR_HTML,
        header="Full Playlist",
        track1=tracks[i],
        track2=tracks[j],
        progress=progress,
        total=total,
        ranking=current_ranking,
        show_embeds=True
    )

@app.route('/results')
def results():
    mode = session.get('mode')
    if mode == 'album':
        album_results = session.get('album_tierlists', {})
        return render_template_string(RESULTS_HTML, album_results=album_results, playlist_result=None)
    else:
        playlist_result = session.get('playlist_result', [])
        return render_template_string(RESULTS_HTML, album_results=None, playlist_result=playlist_result)

@app.route('/cancel', methods=['POST'])
def cancel():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)